INSTRUCTIONS
Note : The following commands are for Windows. 

1. Instructions to Run with a specific set of arguments

python mytcp.py -i <double> -m <double> -n <double> -f <double> -s <double> -T <int> -o outfile



2. Instructions to obtain plots for all sets of argument.
Once executed all the plots will be saved into the "plots" folder

python Generate_plots.py

